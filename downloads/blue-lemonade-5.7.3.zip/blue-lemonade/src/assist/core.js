export const IDS = ['conflicts'];
export const LABELS = { conflicts: '확장 충돌 진단' };
export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// 내장 기능마다 같은 일을 하는 단독 확장 폴더 이름 (addons.js 의 충돌 확인과 여기 진단이 같은 표를 쓴다)
export const DUPLICATES = { tts: ['tts','lemon-voice','lemon-tts'], direction: ['story-direction','Direction-Manager','Direction-Manager-Lite','jeongaejisi'], assets: ['char-assets','character-assets','esetham'], translator: ['llm-translator-custom','llm-translator'], prompt: ['prompt-panel'], customstyle: ['SillyTavern-CustomThemeStyleInputs'], order: ['panel-order'], perf: ['perf-assist'], words: ['word-replace'], models: ['model-register'], rewrite: ['ban-word-rewrite'], bookmarks: ['chat-bookmarks'] };
export function knownConflicts(names, disabled, addons) {
    const active = new Set(names.filter(n => !disabled.includes(n)).map(n => n.replace(/^third-party\//, '')));
    // The host's built-in tts extension is distinct from third-party/tts.
    const thirdParty = new Set(names.filter(n => !disabled.includes(n) && n.startsWith('third-party/')).map(n => n.slice(12)));
    const owner = id => id === 'tts' ? thirdParty : active;
    // 2026-10-06: 문구도 조건과 같은 owner(id) 로 — 'tts' 면 실리태번 내장 tts 까지 별도 확장으로 적혔다
    return Object.entries(DUPLICATES).filter(([id, name]) => addons[id] && (Array.isArray(name)?name.some(folder=>owner(id).has(folder)):owner(id).has(name))).map(([id, name]) => ({ code: 'duplicate-' + id, level: '확인됨', text: `${Array.isArray(name)?name.filter(folder=>owner(id).has(folder)).join(', '):name}: 내장 기능과 별도 확장이 함께 켜져 있어요. 내장 기능은 대기할 수 있어요.` }));
}

import { decorEnabled } from './decor.js';
const ASSET = '.mes_text :is(.custom-cac-img, img.character-asset-rendered, img.eh-img, [class*="custom-imageWrapper"] img)';
const PROFILE = '.mes:not([is_user="true"]):not([is_system="true"]):not(.smallSysMes) > .mesAvatarWrapper > .avatar img';
const USER_PROFILE = '.mes[is_user="true"]:not([is_system="true"]):not(.smallSysMes) > .mesAvatarWrapper > .avatar img';
const wrapped = new Map();
// 숨기기·보이기는 이미 그려진 메시지의 is_system 만 바꾼다. 그 메시지는 다시 맞춰 본다.
const SELECTORS = { image: ASSET, profile: PROFILE, userProfile: USER_PROFILE };
const toggled = new Set();
const isMes = node => node.nodeType === 1 && node.classList.contains('mes');
let state = { image: false, profile: false, userProfile: false }, observer = null, roots = [], frame = 0;
const dirty = new Set();
const hasImage = node => node.nodeType === 1 && (node.tagName === 'IMG' || node.querySelector('img'));
const maskCache = new Map(), maskSources = {};
function windowFor(mask) {
    if (maskCache.has(mask)) return maskCache.get(mask);
    if (maskCache.size >= 4) maskCache.delete(maskCache.keys().next().value);
    const job = new Promise(resolve => {
        const image = new Image();
        image.onerror = () => resolve('0%');
        image.onload = () => {
            try {
            // Legacy saved frames have only a PNG mask. Read its bounds once so
            // rounding clips the inner photo window, not the outer canvas.
            const scale = Math.min(1, 1200 / Math.max(image.naturalWidth, image.naturalHeight));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(image.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
            const { width: w, height: h } = canvas, pixels = ctx.getImageData(0, 0, w, h).data;
            let left = w, top = h, right = -1, bottom = -1;
            for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (pixels[(y * w + x) * 4 + 3] > 8) {
                left = Math.min(left, x); top = Math.min(top, y); right = Math.max(right, x); bottom = Math.max(bottom, y);
            }
            resolve(right < 0 ? '0%' : `${top / h * 100}% ${(w - right - 1) / w * 100}% ${(h - bottom - 1) / h * 100}% ${left / w * 100}%`);
            canvas.width = canvas.height = 1;
            } catch { resolve('0%'); }
        };
        image.src = mask;
    });
    maskCache.set(mask, job); return job;
}
function syncWindows(settings, enabled) {
    for (const kind of ['image', 'profile', 'userProfile']) {
        const mask = enabled[kind] ? settings[kind].decor.mask : '';
        if (maskSources[kind] === mask) continue;
        maskSources[kind] = mask;
        document.documentElement.style.removeProperty(`--bl-${kind === 'userProfile' ? 'user-profile' : kind}-decor-window`);
        if (mask) windowFor(mask).then(value => {
            if (maskSources[kind] === mask) document.documentElement.style.setProperty(`--bl-${kind === 'userProfile' ? 'user-profile' : kind}-decor-window`, value);
        });
    }
}
function undo(img, info) {
    if (info.kind !== 'image') { info.slot.replaceWith(img); info.host.classList.remove('bl-art-frame'); delete info.host.dataset.blFrame; }
    else info.host.replaceWith(img);
    wrapped.delete(img);
}
function wrap(img, kind) {
    if (wrapped.has(img) || !img.parentElement) return;
    const host = kind !== 'image' ? img.closest('.avatar') : document.createElement('span');
    const slot = document.createElement('span'); slot.className = 'bl-art-photo';
    if (kind === 'image') img.replaceWith(host);
    host.classList.add('bl-art-frame'); host.dataset.blFrame = kind;
    if (kind !== 'image') img.replaceWith(slot); else host.append(slot);
    slot.append(img); wrapped.set(img, { host, slot, kind });
}
function scan(root) {
    if (root.nodeType !== 1 || !root.isConnected) return;
    for (const [kind, selector] of [['image', ASSET], ['profile', PROFILE], ['userProfile', USER_PROFILE]]) {
        if (!state[kind]) continue;
        if (root.matches(selector)) wrap(root, kind);
        for (const img of root.querySelectorAll(selector)) wrap(img, kind);
    }
}
function listen() { for (const root of roots) observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['is_system'] }); }
function note(records) {
    for (const rec of records) {
        if (rec.type === 'attributes') { if (isMes(rec.target)) toggled.add(rec.target); continue; }
        for (const node of rec.addedNodes) if (hasImage(node)) dirty.add(node);
    }
}
function flush() {
    frame = 0;
    // 직접 만든 감싸기 요소의 변경 알림은 남기지 않는다.
    const queued = observer?.takeRecords() || [];
    note(queued);
    observer?.disconnect();
    for (const [img, info] of wrapped) {
        if (!info.host.contains(img)) {
            // An extension may replace/remove the photo itself. Preserve its new
            // nodes and remove our empty shell instead of resurrecting the old image.
            info.slot.replaceWith(...info.slot.childNodes);
            if (info.kind !== 'image') { info.host.classList.remove('bl-art-frame'); delete info.host.dataset.blFrame; }
            else info.host.replaceWith(...info.host.childNodes);
            wrapped.delete(img); continue;
        }
        if (!img.isConnected) { undo(img, info); continue; }
        if (!state[info.kind]) undo(img, info);
    }
    for (const mes of toggled) {
        // 숨긴 메시지의 사진은 액자에서 꺼내고, 다시 보이면 아래 scan 이 감싼다.
        for (const img of mes.querySelectorAll('.mesAvatarWrapper > .avatar img')) {
            const info = wrapped.get(img);
            if (info && info.kind !== 'image' && !img.matches(SELECTORS[info.kind])) undo(img, info);
        }
        if (mes.isConnected) dirty.add(mes);
    }
    toggled.clear();
    for (const root of dirty) scan(root);
    dirty.clear();
    if (state.image || state.profile || state.userProfile) listen();
}
export function syncDecorView(settings) {
    const next = decorEnabled(settings);
    syncWindows(settings, next);
    const nextRoots = [...document.querySelectorAll('#chat, .salty-preview')];
    if (observer && next.image === state.image && next.profile === state.profile && next.userProfile === state.userProfile && nextRoots.length === roots.length && nextRoots.every((root, i) => root === roots[i])) return;
    state = next; roots = nextRoots;
    if (!observer) observer = new MutationObserver(records => {
        note(records);
        // 삭제만 된 경우에도 참조를 해제한다.
        if (!frame && (dirty.size || toggled.size || records.some(rec => [...rec.removedNodes].some(hasImage)))) frame = requestAnimationFrame(flush);
    });
    cancelAnimationFrame(frame); frame = 0;
    if (state.image || state.profile || state.userProfile) for (const root of roots) dirty.add(root);
    flush();
}
